import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class Game extends JPanel implements Runnable,KeyListener{
	private BufferedImage back;
	private int key;
	private Box r3;
	private Box r4;
	private Box r5;
	private Box r6;
	private Box r7;
	private Sound p;
	private Pictures bi;
	private Sound birdy;
	private int score;
	private Pictures bird;
	private int collision;
	private double dx;
	private ArrayList <Box> obs;
	private boolean win;
	
	public Game() {
		back=null;
		new Thread(this).start();
		this.addKeyListener(this);
		bi=new Pictures("fpb.png",0,0,800,600);
		score=0;
		key=-1;
		r3= new Box();
		r4=new Box(240,380);
		r5=new Box(390,400);
		r6=new Box(530,400);
		r7=new Box(670,400);
		
		Sound p=new Sound();
		p.playmusic("mario.wav");
		
		Sound birdy= new Sound();
		birdy.playmusic("birdy.wav");
						
		obs= setObs();
		dx=0;
		win=false;
		
		bird=new Pictures("bird.png",10,300,1,1,50,50,true,false);
		collision=1;
			}
	
	private ArrayList<Box> setObs() {
		// TODO Auto-generated method stub
		
		ArrayList <Box> temp = new ArrayList <Box> ();
		temp.add(new Box(90, 0, 70, 310));
		temp.add(new Box(90,430, 70, 310));
		
		temp.add(new Box(240, 0, 70,270));
		temp.add(new Box(240, 400, 70, 400));
		
		temp.add(new Box(390,0,70,320));
		temp.add(new Box(390,440,70,160));
		
		temp.add(new Box(530,0,70,380));
		temp.add(new Box(530,500,70,290));
		
		temp.add(new Box(670,0,70,360));
		temp.add(new Box(670,460,70,170));
	      
		return temp;
	}

	public void run() {
		try {
            			while(true) {
				Thread.currentThread().sleep(5);
				repaint();
			}
		}
		catch(Exception e) {}
	}
public void paint (Graphics g)
{

	Graphics2D twoDgraph = (Graphics2D)g;
		//take a snap shop of the current screen and same it as an image
		//that is the exact same width and height as the current screen

			if (back==null) {

				back =(BufferedImage) (createImage(getWidth(), getHeight()));
			}
				//create a graphics reference to the back ground image
				//we will draw all changes on the background image

			Graphics g2d = back.createGraphics();
				//this clears the old image, like an EtchASketch. If you see the old image when we learn motion, you deleted this line.

			g2d.clearRect(0, 0, getSize().width, getSize().height);
			g2d.drawImage(new ImageIcon(bi.getPic()).getImage(),bi.getX(),bi.getY(), bi.getwidth(), bi.getheight(), this);

			//g2d.fillRect(r3.getX(),r3.getY(), r3.getW(),r3.getH());
			//g2d.fillRect(r4.getX(),r4.getY(), r4.getW(),r4.getH());
			//g2d.setColor(Color.WHITE);
			//g2d.fillRect(r5.getX(),r5.getY(), r5.getW(),r5.getH());
			//g2d.fillRect(r6.getX(),r6.getY(), r6.getW(),r6.getH());
			//g2d.fillRect(r7.getX(),r7.getY(), r7.getW(),r7.getH());

			g2d.setColor(Color.green);
			g2d.setFont(new Font("chiller",Font.BOLD,25));
			g2d.drawString("SCORE " +score,0,30);

				if(win) {
					g2d.setFont(new Font("chiller", Font.BOLD,100));
					g2d.drawString("Game Over", 220, 300);
}
			else {
				move();
        	}
				
				
				
	if(bird.Collision(r3)&&collision==1) {
	collision++;
		score+=10;}
	
	if(bird.Collision(r4)&&collision==2) {
	collision++;
	score+=10;
}
	if(bird.Collision(r5)&&collision==3) {
		collision++;
		score+=10;
	}
	if(bird.Collision(r6)&&collision==4) {
		collision++;
		score+=10;
	}
	if(bird.Collision(r7)&&collision==5) {
		collision++;
		score+=10;
	}
	
		
	
	
	//START CODING GRAPHICS HERE
	g2d.drawImage(new ImageIcon(bird.getPic()).getImage(),bird.getX(),bird.getY(),bird.getwidth(),bird.getheight(),this);
	g2d.setColor(Color.GREEN);

	for(int i=0; i<obs.size(); i++) {
		g2d.fillRect(obs.get(i).getX(),obs.get(i).getY(), obs.get(i).getW(), obs.get(i).getH());
		if(bird.Collision(obs.get(i))) {
			System.out.println("collision!!!");
			obs.clear();
		
			win=true;
		//g2d.drawImage(new ImageIcon(bi.getPic()).getImage(),bi.getX(),bi.getY(), bi.getwidth(), bi.getheight(), this);
	}
}
	dx+=.6;
}
twoDgraph.drawImage (back, 0, 0, null);




public void move() {
	bird.move((int)dx);
}
	public void keyTyped(KeyEvent e){
		
}

		public void keyPressed(KeyEvent e){
			key=e.getKeyCode();
				System.out.println(key);
	/*	if(key==39){
		bird.setDx()dx);
		}
		if(key==37) {
		bird.setDx((int)-dx);
		}
		if(key==40) {
			bird.setDy(1);
		}
		if(key==38) {
			bird.setDy(-2);
		}
		*/
		if(key==32) {
			bird.setDy(-1);
		}			

}
	public void keyReleased(KeyEvent e){
		key=e.getKeyCode();
		if(key==39) {
			//bird.setDx((int)dx);
		}
		if(key==37) {
		//	bird.setDx((int)dx);
		}
		if(key==40){
		//	bird.setDy(0);
		}
		if(key==32){
			bird.setDy(1);
		}


{
}
}}